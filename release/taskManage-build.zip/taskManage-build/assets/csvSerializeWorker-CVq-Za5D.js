(function(){"use strict";const r=["taskId","taskName","parentTaskId","status","startDate","endDate","assignee","priority","project","category","description","displayOrder"];function i(s){return s.includes(",")||s.includes('"')||s.includes(`
`)?`"${s.replace(/"/g,'""')}"`:s}function o(s){const e=r.join(","),n=s.map(t=>r.map(c=>{const a=t[c];return i(a==null?"":String(a))}).join(","));return[e,...n].join(`
`)}self.onmessage=s=>{const{id:e,tasks:n}=s.data,t={id:e,csvText:o(n)};self.postMessage(t)}})();
