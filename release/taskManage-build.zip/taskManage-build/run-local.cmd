@echo off
setlocal
cd /d "%~dp0"
set "PORT=4173"

set "PYTHON_CMD="

where py >nul 2>&1
if %errorlevel%==0 (
  py -3 -c "import sys" >nul 2>&1
  if %errorlevel%==0 (
    set "PYTHON_CMD=py -3"
  )
)

if not defined PYTHON_CMD (
  where python >nul 2>&1
  if %errorlevel%==0 (
    python -c "import sys" >nul 2>&1
    if %errorlevel%==0 (
      set "PYTHON_CMD=python"
    )
  )
)

if not defined PYTHON_CMD (
  echo [ERROR] A usable Python 3 runtime was not found.
  echo.
  echo If you see "Python was not found; run without arguments to install from the Microsoft Store...",
  echo disable the Python alias in:
  echo   Settings ^> Apps ^> Advanced app settings ^> App execution aliases
  echo then install Python 3 from https://www.python.org/downloads/windows/
  echo.
  pause
  exit /b 1
)

echo Starting local server at http://localhost:%PORT% ...
start "" powershell -NoProfile -Command "Start-Sleep -Seconds 2; Start-Process 'http://localhost:%PORT%'"
%PYTHON_CMD% -m http.server %PORT%
