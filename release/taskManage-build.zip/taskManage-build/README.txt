TaskManage ビルド版（Windows 11 ローカル実行想定）

■ 使い方
1. このZIPを任意の場所に解凍
2. PowerShellで解凍先フォルダへ移動
3. `./run-local.cmd` を実行
4. ブラウザで http://localhost:4173 を開く

■ トラブルシュート
- `localhost で接続が拒否されました` と表示される場合:
  - サーバー起動直後の可能性があります。数秒待って再読み込みしてください。
- `Python was not found; run without arguments to install from the Microsoft Store ...` と表示される場合:
  - Windows の App execution aliases が反応している可能性があります。
  - `py -V` が使えるか確認し、使えない場合は Python 3 をインストールしてください。
